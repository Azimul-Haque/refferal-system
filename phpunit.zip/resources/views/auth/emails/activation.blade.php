Hi, <br/><br/>

Please find the link below and click it activate your account.

<br/><br/>

Activation link: {{ $url }} <br/><br/>

Thanks,<br/>
The Admin Team