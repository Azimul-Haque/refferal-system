@extends('layouts.homepage')

@section('title', 'Home | The Refferal System')

@section('stylesheet')
  {!!Html::style('')!!}
@endsection

@section('content-homepage')
    
@endsection

@section('script')
    {!!Html::script('')!!}
@endsection