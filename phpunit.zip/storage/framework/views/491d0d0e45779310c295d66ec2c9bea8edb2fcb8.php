Hi, <br/><br/>

Please find the link below and click it activate your account.

<br/><br/>

Activation link: <?php echo e($url); ?> <br/><br/>

Thanks,<br/>
The Admin Team